import{c as s}from"./shield-alert-CDCTPXI9.js";/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=s("Minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);export{c as M};
//# sourceMappingURL=minus-CgCpFT9W.js.map
