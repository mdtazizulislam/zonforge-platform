import{c as t}from"./shield-alert-CDCTPXI9.js";/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=t("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);export{h as C};
//# sourceMappingURL=chevron-right-CiqCd0Nt.js.map
