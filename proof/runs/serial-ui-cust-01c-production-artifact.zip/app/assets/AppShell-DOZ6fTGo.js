import{j as e}from"./query-B87dvy2N.js";import{c as n}from"./charts-B2Rg4g8L.js";import{u,L as k}from"./router-CCJgc4Pc.js";import{u as g,b}from"./index-di5HF8hP.js";import{c as s,S as j}from"./shield-alert-CDCTPXI9.js";import{C as v,S as M}from"./sparkles-UcrhyVbG.js";import{L as x,S as N,a as C}from"./settings-Cyqb6Uto.js";/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const S=s("BookOpen",[["path",{d:"M12 7v14",key:"1akyts"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",key:"ruj8y"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=s("Brain",[["path",{d:"M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z",key:"l5xja"}],["path",{d:"M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z",key:"ep3f8r"}],["path",{d:"M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4",key:"1p4c4q"}],["path",{d:"M17.599 6.5a3 3 0 0 0 .399-1.375",key:"tmeiqw"}],["path",{d:"M6.003 5.125A3 3 0 0 0 6.401 6.5",key:"105sqy"}],["path",{d:"M3.477 10.896a4 4 0 0 1 .585-.396",key:"ql3yin"}],["path",{d:"M19.938 10.5a4 4 0 0 1 .585.396",key:"1qfode"}],["path",{d:"M6 18a4 4 0 0 1-1.967-.516",key:"2e4loj"}],["path",{d:"M19.967 17.484A4 4 0 0 1 18 18",key:"159ez6"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const A=s("Building2",[["path",{d:"M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z",key:"1b4qmf"}],["path",{d:"M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2",key:"i71pzd"}],["path",{d:"M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2",key:"10jefs"}],["path",{d:"M10 6h4",key:"1itunk"}],["path",{d:"M10 10h4",key:"tcdvrf"}],["path",{d:"M10 14h4",key:"kelpxr"}],["path",{d:"M10 18h4",key:"1ulq68"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=s("ChartColumn",[["path",{d:"M3 3v16a2 2 0 0 0 2 2h16",key:"c24i48"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=s("CreditCard",[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const V=s("FileSearch",[["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M4.268 21a2 2 0 0 0 1.727 1H18a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v3",key:"ms7g94"}],["path",{d:"m9 18-1.5-1.5",key:"1j6qii"}],["circle",{cx:"5",cy:"14",r:"3",key:"ufru5t"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q=s("FlaskConical",[["path",{d:"M10 2v7.527a2 2 0 0 1-.211.896L4.72 20.55a1 1 0 0 0 .9 1.45h12.76a1 1 0 0 0 .9-1.45l-5.069-10.127A2 2 0 0 1 14 9.527V2",key:"pzvekw"}],["path",{d:"M8.5 2h7",key:"csnxdl"}],["path",{d:"M7 16h10",key:"wp8him"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=s("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const B=s("MessageSquare",[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",key:"1lielz"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const I=s("Network",[["rect",{x:"16",y:"16",width:"6",height:"6",rx:"1",key:"4q2zg0"}],["rect",{x:"2",y:"16",width:"6",height:"6",rx:"1",key:"8cvhb9"}],["rect",{x:"9",y:"2",width:"6",height:"6",rx:"1",key:"1egb70"}],["path",{d:"M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3",key:"1jsf9p"}],["path",{d:"M12 12V8",key:"2874zd"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const O=s("ShieldCheck",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=s("Shield",[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const F=s("Wifi",[["path",{d:"M12 20h.01",key:"zekei9"}],["path",{d:"M2 8.82a15 15 0 0 1 20 0",key:"dnpr2z"}],["path",{d:"M5 12.859a10 10 0 0 1 14 0",key:"1x1e6c"}],["path",{d:"M8.5 16.429a5 5 0 0 1 7 0",key:"1bycff"}]]),H=[{label:"Dashboard",href:"/dashboard",icon:x,exact:!0},{label:"Customer Dashboard",href:"/customer-dashboard",icon:x},{label:"Alerts",href:"/alerts",icon:j},{label:"AI SOC Analyst",href:"/ai-soc-analyst",icon:w},{label:"AI Intelligence",href:"/ai-intelligence",icon:M},{label:"AI Assistant",href:"/ai-assistant",icon:B},{label:"Investigations",href:"/investigations",icon:V},{label:"Risk",href:"/risk",icon:z},{label:"Threat Hunting",href:"/threat-hunting",icon:N},{label:"Security Validation",href:"/security-validation",icon:q},{label:"Supply Chain",href:"/supply-chain",icon:I},{label:"Enterprise",href:"/enterprise",icon:c},{label:"Connectors",href:"/connectors",icon:F}],W=[{label:"Compliance",href:"/compliance",icon:O},{label:"Audit Log",href:"/audit",icon:S},{label:"MSSP",href:"/mssp",icon:A},{label:"Enterprise Sales",href:"/enterprise-sales",icon:y},{label:"Billing",href:"/billing",icon:y},{label:"Settings",href:"/settings",icon:C}];function Z(){var d,p;const l=u(),{user:t,clearAuth:i}=g(),{sidebarCollapsed:r,toggleSidebar:f}=b();function m(a,o=!1){return o?l.pathname===a:l.pathname.startsWith(a)}function h({item:a}){const o=m(a.href,a.exact);return e.jsxs(k,{to:a.href,className:n("flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",o?"bg-blue-500/15 text-blue-400":"text-gray-500 hover:text-gray-300 hover:bg-gray-800/60",r&&"justify-center px-2"),title:r?a.label:void 0,children:[e.jsx(a.icon,{className:n("flex-shrink-0",r?"h-5 w-5":"h-4 w-4",o?"text-blue-400":"text-gray-600")}),!r&&e.jsx("span",{className:"truncate",children:a.label})]})}return e.jsxs("aside",{className:n("flex flex-col h-full bg-gray-950 border-r border-gray-800 transition-all duration-200",r?"w-16":"w-56"),children:[e.jsxs("div",{className:"flex items-center justify-between px-3 h-14 border-b border-gray-800",children:[!r&&e.jsxs("div",{className:"flex items-center gap-2.5",children:[e.jsx("div",{className:"rounded-lg bg-blue-500/20 p-1.5",children:e.jsx(c,{className:"h-4 w-4 text-blue-400"})}),e.jsxs("div",{children:[e.jsx("p",{className:"text-sm font-bold text-gray-100 leading-none",children:"ZonForge"}),e.jsx("p",{className:"text-xs text-gray-600 leading-none mt-0.5",children:"Sentinel"})]})]}),r&&e.jsx("div",{className:"mx-auto rounded-lg bg-blue-500/20 p-1.5",children:e.jsx(c,{className:"h-4 w-4 text-blue-400"})}),e.jsx("button",{onClick:f,title:"Collapse sidebar","aria-label":"Collapse sidebar",className:n("text-gray-600 hover:text-gray-400 p-1 rounded transition-colors",r&&"hidden"),children:e.jsx(v,{className:"h-4 w-4"})})]}),e.jsx("nav",{className:"flex-1 px-2 py-3 space-y-0.5",children:H.map(a=>e.jsx(h,{item:a},a.href))}),e.jsxs("div",{className:"px-2 py-3 border-t border-gray-800 space-y-0.5",children:[W.map(a=>e.jsx(h,{item:a},a.href)),e.jsxs("div",{className:n("flex items-center gap-3 px-3 py-2 mt-2 border-t border-gray-800/60 pt-3",r&&"justify-center"),children:[e.jsx("div",{className:`flex-shrink-0 h-7 w-7 rounded-full bg-blue-500/20 flex items-center\r
                          justify-center text-blue-400 font-bold text-xs`,children:((p=(d=t==null?void 0:t.name)==null?void 0:d[0])==null?void 0:p.toUpperCase())??"?"}),!r&&e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsx("p",{className:"text-xs font-medium text-gray-300 truncate",children:(t==null?void 0:t.name)??"—"}),e.jsx("p",{className:"text-xs text-gray-600 truncate",children:(t==null?void 0:t.role)??"—"})]}),e.jsx("button",{onClick:i,title:"Log out",className:"flex-shrink-0 text-gray-700 hover:text-red-400 transition-colors",children:e.jsx(L,{className:"h-3.5 w-3.5"})})]})]})]})}function G({children:l,title:t,actions:i}){const{sidebarCollapsed:r}=b();return e.jsxs("div",{className:"flex h-screen overflow-hidden bg-gray-950",children:[e.jsx(Z,{}),e.jsxs("main",{className:"flex-1 flex flex-col overflow-hidden",children:[(t||i)&&e.jsxs("header",{className:`flex items-center justify-between px-6 py-4 border-b border-gray-800\r
                             bg-gray-950/90 backdrop-blur sticky top-0 z-10`,children:[e.jsx("h1",{className:"text-base font-semibold text-gray-100",children:t}),i&&e.jsx("div",{className:"flex items-center gap-2",children:i})]}),e.jsx("div",{className:"flex-1 overflow-y-auto",children:l})]})]})}function J({children:l,className:t}){return e.jsx("div",{className:n("p-6 max-w-screen-2xl mx-auto",t),children:l})}export{G as A,S as B,y as C,V as F,B as M,I as N,J as P,c as S,F as W,O as a,A as b,z as c,q as d,w as e};
//# sourceMappingURL=AppShell-DOZ6fTGo.js.map
